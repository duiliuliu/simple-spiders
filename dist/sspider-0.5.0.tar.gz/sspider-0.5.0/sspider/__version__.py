#      _              _       ___       _    _
#  ___<_>._ _ _  ___ | | ___ / __> ___ <_> _| | ___  _ _
# <_-<| || ' ' || . \| |/ ._>\__ \| . \| |/ . |/ ._>| '_>
# /__/|_||_|_|_||  _/|_|\___.<___/|  _/|_|\___|\___.|_|
#               |_|               |_|


__title__ = 'sspider'
__description__ = 'A simple web crawling framework.'
__url__ = 'https://duiliuliu.github.io/sspider/'
__version__ = '1.0.1'
__author__ = 'pengr'
__author_email__ = 'pengrui55555@163.com'
__copyright__ = 'Copyright 2018 Pengr'
